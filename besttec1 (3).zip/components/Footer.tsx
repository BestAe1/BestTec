"use client"
import { useLanguage } from "@/contexts/LanguageContext"
import Link from "next/link"

export default function Footer() {
  const { language } = useLanguage()

  return (
    <footer className="w-full bg-black border-t border-gray-800 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 lg:py-12">
        <div className="text-center">
          {/* Links */}
          <div className="flex flex-wrap justify-center gap-4 sm:gap-6 lg:gap-8 mb-6 sm:mb-8">
            <Link href="/" className="text-gray-300 hover:text-white transition-colors text-sm sm:text-base lg:text-lg">
              {language === "ar" ? "صفحة BestPlatec الرئيسية" : "BestPlatec Home"}
            </Link>
            <a href="#" className="text-gray-300 hover:text-white transition-colors text-sm sm:text-base lg:text-lg">
              {language === "ar" ? "شروط الاستخدام" : "Terms of Use"}
            </a>
            <a href="#" className="text-gray-300 hover:text-white transition-colors text-sm sm:text-base lg:text-lg">
              {language === "ar" ? "سياسة الخصوصية" : "Privacy Policy"}
            </a>
          </div>

          {/* Copyright */}
          <p className="text-white font-medium text-sm sm:text-base lg:text-lg">
            {language === "ar" ? "جميع الحقوق محفوظة © BestPlatec 2025" : "All Rights Reserved © BestPlatec 2025"}
          </p>
        </div>
      </div>
    </footer>
  )
}
