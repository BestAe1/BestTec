"use client"

import { useState, useEffect } from "react"
import { X, ChevronDown, ChevronRight, User } from "lucide-react"
import { useLanguage } from "@/contexts/LanguageContext"
import Link from "next/link"

interface SidebarProps {
  isOpen: boolean
  onClose: () => void
}

export default function Sidebar({ isOpen, onClose }: SidebarProps) {
  const { language, setLanguage, theme, setTheme } = useLanguage()
  const [expandedSections, setExpandedSections] = useState<string[]>([])

  const toggleSection = (section: string) => {
    setExpandedSections((prev) => (prev.includes(section) ? prev.filter((s) => s !== section) : [...prev, section]))
  }

  const isExpanded = (section: string) => expandedSections.includes(section)

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden"
      document.body.style.position = "fixed"
      document.body.style.width = "100%"
      document.body.style.top = "0"
    } else {
      document.body.style.overflow = ""
      document.body.style.position = ""
      document.body.style.width = ""
      document.body.style.top = ""
    }
    return () => {
      document.body.style.overflow = ""
      document.body.style.position = ""
      document.body.style.width = ""
      document.body.style.top = ""
    }
  }, [isOpen])

  if (!isOpen) return null

  const menuItems = [
    { labelAr: "صفحة BestTec الرئيسية", labelEn: "BestTec Home", href: "/" },
    { labelAr: "الصور", labelEn: "Photos", href: "/photos" },
    { labelAr: "الفيديو", labelEn: "Videos", href: "/videos" },
    { labelAr: "الملفات", labelEn: "Files", href: "/files" },
    { labelAr: "الألعاب", labelEn: "Games", href: "/games" },
    { labelAr: "اللغة", labelEn: "Language", section: "language" },
    { labelAr: "الإعدادات", labelEn: "Settings", section: "settings" },
    { labelAr: "الحساب", labelEn: "Account", href: "/account" },
    { labelAr: "شروط الاستخدام", labelEn: "Terms of Use", href: "/terms" },
    { labelAr: "سياسة الخصوصية", labelEn: "Privacy Policy", href: "/privacy" },
  ]

  return (
    <>
      <div className="fixed inset-0 bg-black bg-opacity-50 z-50" onClick={onClose} />

      <div
        className={`fixed top-0 h-full w-[280px] sm:w-[320px] bg-white z-50 shadow-2xl flex flex-col ${
          language === "ar" ? "right-0" : "left-0"
        }`}
        dir={language === "ar" ? "rtl" : "ltr"}
      >
        {/* Header */}
        <div className="relative h-[150px] bg-black border-b border-gray-200">
          <div className="absolute w-full h-full">
            <div className="absolute" style={{ top: 12, [language === "ar" ? "left" : "right"]: 12 }}>
              <button onClick={onClose} className="p-1 hover:bg-gray-800 rounded-lg">
                <X className="w-6 h-6 text-white" />
              </button>
            </div>
            <div className="absolute" style={{ bottom: 30, [language === "ar" ? "right" : "left"]: 12 }}>
              <h2 className="text-[24px] font-bold text-white">BestTec</h2>
            </div>
            <div className="absolute" style={{ bottom: 30, [language === "ar" ? "left" : "right"]: 12 }}>
              <button className="p-1 hover:bg-gray-800 rounded-lg">
                <User className="w-6 h-6 text-white" />
              </button>
            </div>
          </div>
        </div>

        {/* Navigation + Footer scrollable */}
        <div className="flex-1 overflow-y-auto">
          <nav className="p-3">
            <div className="flex flex-col gap-3">
              {menuItems.map((item, idx) => (
                <div key={idx}>
                  {item.href ? (
                    <Link href={item.href} onClick={onClose} className="block">
                      <div className="py-2 px-3 hover:bg-gray-100 rounded-lg cursor-pointer">
                        <span className="text-[20px] font-medium">
                          {language === "ar" ? item.labelAr : item.labelEn}
                        </span>
                      </div>
                    </Link>
                  ) : item.section ? (
                    <>
                      <button
                        onClick={() => toggleSection(item.section!)}
                        className="w-full flex items-center justify-between py-2 px-3 hover:bg-gray-100 rounded-lg"
                      >
                        <span className="text-[20px] font-medium">
                          {language === "ar" ? item.labelAr : item.labelEn}
                        </span>
                        <span className={`${language === "ar" ? "mr-[20px]" : "ml-[20px]"}`}>
                          {isExpanded(item.section!) ? (
                            <ChevronDown className="w-5 h-5" />
                          ) : (
                            <ChevronRight className="w-5 h-5" />
                          )}
                        </span>
                      </button>

                      {/* Sub-items for language */}
                      {item.section === "language" && isExpanded("language") && (
                        <div className="mt-1">
                          {[
                            { label: "العربية", value: "ar" },
                            { label: "English", value: "en" },
                          ].map((langItem, i) => (
                            <button
                              key={i}
                              onClick={() => setLanguage(langItem.value)}
                              className={`w-full py-2 px-3 hover:bg-gray-100 rounded-lg text-[18px] ${
                                language === langItem.value ? "bg-gray-100 font-semibold" : ""
                              } ${language === "ar" ? "text-right" : "text-left"}`}
                            >
                              {langItem.label}
                            </button>
                          ))}
                        </div>
                      )}

                      {/* Sub-items for settings */}
                      {item.section === "settings" && isExpanded("settings") && (
                        <div className="mt-1">
                          <button
                            onClick={() => toggleSection("theme")}
                            className="w-full flex items-center justify-between py-2 px-3 hover:bg-gray-100 rounded-lg"
                          >
                            <span className="text-[18px]">{language === "ar" ? "المظهر" : "Theme"}</span>
                            <span className={`${language === "ar" ? "mr-[20px]" : "ml-[20px]"}`}>
                              {isExpanded("theme") ? (
                                <ChevronDown className="w-4 h-4" />
                              ) : (
                                <ChevronRight className="w-4 h-4" />
                              )}
                            </span>
                          </button>

                          {isExpanded("theme") && (
                            <div className="mt-1">
                              {[
                                { label: language === "ar" ? "فاتح" : "Light", value: "light" },
                                { label: language === "ar" ? "داكن" : "Dark", value: "dark" },
                              ].map((themeItem, tIdx) => (
                                <button
                                  key={tIdx}
                                  onClick={() => setTheme(themeItem.value as "light" | "dark")}
                                  className={`w-full py-2 px-3 hover:bg-gray-100 rounded-lg text-[18px] ${
                                    theme === themeItem.value ? "bg-gray-100 font-semibold" : ""
                                  } ${language === "ar" ? "text-right" : "text-left"}`}
                                >
                                  {themeItem.label}
                                </button>
                              ))}
                            </div>
                          )}
                        </div>
                      )}
                    </>
                  ) : (
                    <div className="py-2 px-3 hover:bg-gray-100 rounded-lg cursor-pointer">
                      <span className="text-[20px] font-medium">{language === "ar" ? item.labelAr : item.labelEn}</span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </nav>

          {/* Footer inside scrollable area */}
          <div className="border-t border-gray-200 p-4 text-center bg-gray-50 mt-4">
            <div className="text-black text-[20px] font-bold">BestTec</div>
          </div>
        </div>
      </div>
    </>
  )
}
