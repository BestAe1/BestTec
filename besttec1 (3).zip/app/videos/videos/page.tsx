"use client"
import { useLanguage } from "@/contexts/LanguageContext"
import { useState } from "react"
import { Search, X, Download, ArrowLeft, ArrowRight } from "lucide-react"
import { useRouter } from "next/navigation"

export default function VideosListPage() {
  const { language } = useLanguage()
  const isArabic = language === "ar"
  const router = useRouter()
  const [search, setSearch] = useState("")
  const [showFilter, setShowFilter] = useState(false)

  const filters = [
    isArabic ? "الأحدث" : "Newest",
    isArabic ? "الأقدم" : "Oldest",
    isArabic ? "حسب الحجم" : "By Size",
    isArabic ? "حسب التاريخ" : "By Date",
  ]

  const handleBack = () => {
    router.back()
  }

  return (
    <div dir={isArabic ? "rtl" : "ltr"} className="min-h-screen bg-white px-4 py-6">
      {/* Header with Back Button */}
      <div className="flex items-center justify-between mb-6">
        <button
          onClick={handleBack}
          className="flex items-center gap-2 text-gray-600 hover:text-black transition-colors text-sm sm:text-base lg:text-lg"
        >
          {isArabic ? (
            <ArrowRight className="w-4 h-4 sm:w-5 sm:h-5" />
          ) : (
            <ArrowLeft className="w-4 h-4 sm:w-5 sm:h-5" />
          )}
          <span>{isArabic ? "العودة" : "Back"}</span>
        </button>
        <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold">{isArabic ? "الفيديوهات" : "Videos"}</h1>
        <div className="w-16 sm:w-20"></div>
      </div>

      {/* Search Bar + Filter */}
      <div className="flex justify-center mb-6 gap-2">
        <div
          className="flex items-center border-2 border-gray-300 overflow-hidden w-[350px] h-[50px]"
          style={{ borderRadius: "10px 30px 30px 10px" }}
        >
          {isArabic ? (
            <>
              <div className="flex items-center justify-center w-[50px] h-full bg-gray-100 border-l-2 border-gray-300">
                <Search className="w-5 h-5 text-gray-500" />
              </div>
              <div className="relative flex-1">
                <input
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="ابحث عن فيديو..."
                  className="w-full h-full px-4 text-right text-[16px] focus:outline-none"
                />
                {search && (
                  <button
                    onClick={() => setSearch("")}
                    className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-black"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>
            </>
          ) : (
            <>
              <div className="relative flex-1">
                <input
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search videos..."
                  className="w-full h-full px-4 text-left text-[16px] focus:outline-none"
                />
                {search && (
                  <button
                    onClick={() => setSearch("")}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-black"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>
              <div className="flex items-center justify-center w-[50px] h-full bg-gray-100 border-r-2 border-gray-300">
                <Search className="w-5 h-5 text-gray-500" />
              </div>
            </>
          )}
        </div>

        <button
          onClick={() => setShowFilter(!showFilter)}
          className="px-4 h-[50px] bg-gray-100 border-2 border-gray-300 text-sm font-medium"
          style={{ borderRadius: "10px 30px 30px 10px" }}
        >
          {isArabic ? "فلتر" : "Filter"}
        </button>
      </div>

      {/* Filter Options */}
      {showFilter && (
        <div className="mb-6 flex justify-center">
          <div className="flex gap-3 flex-wrap">
            {filters.map((f, i) => (
              <button key={i} className="bg-gray-200 px-3 py-1 rounded-full text-sm">
                {f}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Videos Content */}
      <div className="grid grid-cols-1 gap-4">
        <div className="bg-gray-100 p-4 rounded-xl flex items-center justify-between">
          <span className="text-gray-800 font-medium text-[18px]">{isArabic ? "فيديو تعليمي" : "Tutorial Video"}</span>
          <button className="text-blue-600 hover:underline flex items-center gap-1">
            <Download className="w-4 h-4" />
            {isArabic ? "تحميل" : "Download"}
          </button>
        </div>
      </div>
    </div>
  )
}
