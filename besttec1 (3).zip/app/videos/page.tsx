"use client"

import { useLanguage } from "@/contexts/LanguageContext"
import { useRouter } from "next/navigation"
import { useState } from "react"
import { Search, X, ArrowLeft, ArrowRight } from "lucide-react"

export default function VideosPage() {
  const { language } = useLanguage()
  const isArabic = language === "ar"
  const router = useRouter()
  const [searchQuery, setSearchQuery] = useState("")

  const handleSearch = () => {
    if (searchQuery.trim() !== "") {
      router.push(`/search?q=${encodeURIComponent(searchQuery)}&type=videos`)
    }
  }

  const handleCardClick = (target: string) => {
    router.push(`/videos/${target}`)
  }

  const handleBack = () => {
    router.back()
  }

  return (
    <div dir={isArabic ? "rtl" : "ltr"} className="min-h-screen bg-white px-4 py-6">
      {/* Header with Back Button */}
      <div className="flex items-center justify-between mb-6">
        <button
          onClick={handleBack}
          className="flex items-center gap-2 text-gray-600 hover:text-black transition-colors text-sm sm:text-base lg:text-lg"
        >
          {isArabic ? (
            <ArrowRight className="w-4 h-4 sm:w-5 sm:h-5" />
          ) : (
            <ArrowLeft className="w-4 h-4 sm:w-5 sm:h-5" />
          )}
          <span>{isArabic ? "العودة" : "Back"}</span>
        </button>
        <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold">{isArabic ? "الفيديو" : "Videos"}</h1>
        <div className="w-16 sm:w-20"></div>
      </div>

      {/* Search Bar */}
      <div className="flex justify-center mb-6">
        <div
          className="flex items-center border-2 border-gray-300 overflow-hidden w-[350px] h-[50px]"
          style={{ borderRadius: "10px 30px 30px 10px" }}
        >
          {isArabic ? (
            <>
              <div className="flex items-center justify-center w-[50px] h-full bg-gray-100 border-l-2 border-gray-300">
                <Search className="w-5 h-5 text-gray-500" />
              </div>
              <div className="relative flex-1">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                  placeholder="ابحث عن الفيديو..."
                  className="w-full h-full px-4 text-right text-[16px] focus:outline-none"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery("")}
                    className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-black"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>
            </>
          ) : (
            <>
              <div className="relative flex-1">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                  placeholder="Search videos..."
                  className="w-full h-full px-4 text-left text-[16px] focus:outline-none"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery("")}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-black"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>
              <div className="flex items-center justify-center w-[50px] h-full bg-gray-100 border-r-2 border-gray-300">
                <Search className="w-5 h-5 text-gray-500" />
              </div>
            </>
          )}
        </div>
      </div>

      {/* Cards */}
      <div className="grid grid-cols-1 gap-4">
        <div
          onClick={() => handleCardClick("videos")}
          className="bg-gray-100 rounded-xl shadow-sm p-6 cursor-pointer hover:bg-gray-200 transition"
        >
          <h2 className="text-lg font-semibold text-gray-800">{isArabic ? "الفيديوهات" : "Videos"}</h2>
          <p className="text-gray-600 text-sm mt-2">
            {isArabic ? "مجموعة متنوعة من الفيديوهات" : "Various collection of videos"}
          </p>
        </div>

        <div
          onClick={() => handleCardClick("video-wallpapers")}
          className="bg-gray-100 rounded-xl shadow-sm p-6 cursor-pointer hover:bg-gray-200 transition"
        >
          <h2 className="text-lg font-semibold text-gray-800">{isArabic ? "خلفيات الفيديو" : "Video Wallpapers"}</h2>
          <p className="text-gray-600 text-sm mt-2">{isArabic ? "خلفيات فيديو متحركة" : "Animated video wallpapers"}</p>
        </div>
      </div>
    </div>
  )
}
